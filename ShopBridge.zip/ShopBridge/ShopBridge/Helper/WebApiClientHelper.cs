﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ShopBridgeModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridge.Helper
{
    public class WebApiClientHelper
    {
        public ReturnedObject ExecuteAPI(ApiInputModel objCommon, Object UrlPathApi = null)
        {
            ReturnedObject retObj = new ReturnedObject();
            string data = string.Empty;
            HttpResponseMessage response = new HttpResponseMessage();
            HttpClient client = new HttpClient();
            // updated aniyan on 18-06-2020
            string url = string.Empty;
            if (UrlPathApi == null)
                url = Program.UrlPath + objCommon.ApiMethod;
            else
                url = UrlPathApi + objCommon.ApiMethod;
            client.DefaultRequestHeaders.TryAddWithoutValidation("Username", objCommon.Username);
            client.DefaultRequestHeaders.TryAddWithoutValidation("Password", objCommon.Password);
            client.DefaultRequestHeaders.TryAddWithoutValidation("MenuID", objCommon.MenuID.ToString());
            var uri = new Uri(string.Format(url, string.Empty));
            var json = Newtonsoft.Json.JsonConvert.SerializeObject(objCommon, new JsonSerializerSettings()
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            });
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            client.BaseAddress = new Uri(url);
            try
            {
                response = client.PostAsync(uri, content).Result;

                if (response.IsSuccessStatusCode)
                {
                    var res = response.Content.ReadAsStringAsync().Result;
                    JObject jo = JObject.Parse(res);
                    json = jo.SelectToken("result").ToString();

                    var statuscode = "";
                    try
                    {
                        if (jo.SelectToken("StatusCode") != null)
                            statuscode = jo.SelectToken("StatusCode").ToString();
                        else if (jo.SelectToken("statusCode") != null)
                            statuscode = jo.SelectToken("statusCode").ToString();
                    }
                    catch
                    {
                        statuscode = "";
                    }

                    if (response.StatusCode.ToString() == "Exception")
                    {
                        Exception obj = JsonConvert.DeserializeObject<Exception>(json.ToString());
                        retObj.Data = obj;
                        retObj.Type = ReturnedObject.ReturnType.Exception;// "Exception";
                        return retObj;
                    }
                    else if (statuscode == "Exception")
                    {
                        Exception obj = JsonConvert.DeserializeObject<Exception>(json.ToString());
                        retObj.Data = obj;
                        retObj.Type = ReturnedObject.ReturnType.Exception;
                        return retObj;
                    }
                    else if (statuscode == "Failed")
                    {
                        retObj.Data = json;
                        retObj.Type = ReturnedObject.ReturnType.Exception;
                        return retObj;
                    }
                    else if (res != "" && res != null && res != "[]")
                    {
                        retObj.Data = json;
                        retObj.Type = ReturnedObject.ReturnType.Ok;
                        return retObj;
                    }
                }
                else
                {
                    Exception ex = new Exception("Could not connect to the API");
                    retObj.Data = ex;
                    retObj.Type = ReturnedObject.ReturnType.Exception;
                    return retObj;
                }
                return retObj;
            }
            catch (Exception ex)
            {
                retObj.Data = ex;
                retObj.Type = ReturnedObject.ReturnType.Exception;
                return retObj;
            }
        }
        public ReturnedObject ExecuteExceptionRetrieval(ApiInputModel objCommon)
        {
            HttpResponseMessage response = new HttpResponseMessage();
            HttpClient client = new HttpClient();
            ReturnedObject retObj = new ReturnedObject();
            string url = Program.UrlPath + objCommon.ApiMethod;
            var uri = new Uri(string.Format(url, string.Empty));
            var json = JsonConvert.SerializeObject(objCommon, new JsonSerializerSettings()
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            });
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            client.BaseAddress = new Uri(url);
            try
            {
                response = client.PostAsync(uri, content).Result;
                if (response.IsSuccessStatusCode)
                {
                    var res = response.Content.ReadAsStringAsync().Result;
                    JObject jo = JObject.Parse(res.ToString());
                    json = jo.SelectToken("result").ToString();

                    retObj.Data = json;
                    retObj.Type = ReturnedObject.ReturnType.Exception;//"OK";
                    return retObj;
                }
                else
                {
                    Exception ex = new Exception("Could not connect to the API");
                    retObj.Data = ex;
                    retObj.Type = ReturnedObject.ReturnType.Exception;
                    return retObj;
                }
            }
            catch (Exception ex)
            {
                retObj.Data = ex;
                retObj.Type = ReturnedObject.ReturnType.Exception;
                return retObj;
            }
        }
        public T ConvertObjectToAnyModel<T>(string json)
        {
            return JsonConvert.DeserializeObject<T>(json);
        }
        public List<T> ConvertObjectToAnyModelList<T>(string json)
        {
            return JsonConvert.DeserializeObject<List<T>>(json);
        }
        public DataTable ConvertObjectToDatatable(string json)
        {
            return JsonConvert.DeserializeObject<DataTable>(json);
        }
        public DataSet ConvertObjectToDataSet(string json)
        {
            return JsonConvert.DeserializeObject<DataSet>(json);
        }
    }
}
