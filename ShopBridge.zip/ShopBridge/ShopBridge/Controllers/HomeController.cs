﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ShopBridge.Models;
using ShopBridge.Helper;
using ShopBridgeModel;

namespace ShopBridge.Controllers
{
    public class HomeController : Controller
    {
        WebApiClientHelper dataHTTP = new WebApiClientHelper();
        ApiInputModel objCommon = new ApiInputModel();

        public IActionResult Index()
        {
            objCommon.Language = "English";
            objCommon.Username = "aniyan";
            objCommon.ApiMethod = "api/GetItemsList";
            ItemModelList ObjModelList = new ItemModelList();
            var retObj = dataHTTP.ExecuteAPI(objCommon);
            if (retObj.Type == ReturnedObject.ReturnType.Ok)
            {
                ObjModelList.ItemsList = dataHTTP.ConvertObjectToAnyModelList<ItemModel>(retObj.Data.ToString());
            }
            else
            {
                if (retObj.Type == ReturnedObject.ReturnType.Failed)
                    ViewBag.Message = retObj.Data;
            }
            return View(ObjModelList);
        }
        public IActionResult Fill(string Id)
        {
            try
            {
                if (Id != "0")
                {
                    objCommon.ApiMethod = "api/GetItem";
                    objCommon.ID = Convert.ToInt64(Id);
                    var retObj = dataHTTP.ExecuteAPI(objCommon);
                    if (retObj.Type == ReturnedObject.ReturnType.Ok)
                    {
                        ObjModel = dataHTTP.ConvertObjectToAnyModel<ItemModel>(retObj.Data.ToString());
                    }
                    else
                    {
                        ViewBag.Message = retObj.Data;
                    }
                }
            }
            catch (Exception)
            { }

            return PartialView(ObjModel);
        }
        public IActionResult Insert(ItemModel objMdl)
        {
            try
            {
                if (objMdl != null)
                {
                    objCommon.ApiMethod = "api/PutItems";
                    objCommon.TypeObject = objMdl;
                    var retObj = dataHTTP.ExecuteAPI(objCommon);
                    if (retObj.Type == ReturnedObject.ReturnType.Ok)
                    {
                        bool Result = Convert.ToBoolean(retObj.Data);
                        if (Result)
                            ViewBag.Message = "Sucess";
                    }
                    else
                    {
                        ViewBag.Message = retObj.Data.ToString();
                    }
                }
                return Json(new { status = "true", message = ViewBag.Message });
            }
            catch (Exception ex)
            {
                return Json(new { status = "false", message = ex.Message });
            }
        }
        public IActionResult Delete(string Id)
        {
            try
            {
                if (Id != "0")
                {
                    objCommon.ApiMethod = "api/DeleteItem";
                    objCommon.ID = Convert.ToInt64(Id);
                    var retObj = dataHTTP.ExecuteAPI(objCommon);
                    if (retObj.Type == ReturnedObject.ReturnType.Ok)
                    {
                        bool Result = Convert.ToBoolean(retObj.Data);
                        if (Result)
                            ViewBag.Message = "Sucess";
                    }
                    else
                    {
                        ViewBag.Message = retObj.Data;
                    }
                }
                return Json(new { status = "true", message = ViewBag.Message });
            }
            catch (Exception ex)
            {
                return Json(new { status = "false", message = ex.Message });
            }
        }
        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }
        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        ShopBridgeModel.ItemModel _objModel;
        ShopBridgeModel.ItemModel ObjModel
        {
            get
            {
                if (_objModel == null)
                {
                    _objModel = new ItemModel();
                }
                return _objModel;
            }
            set
            {
                _objModel = value;
            }
        }
    }
}