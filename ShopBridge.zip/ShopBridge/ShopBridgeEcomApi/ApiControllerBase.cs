﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ShopBridgeEcomApi.Helper;
using ShopBridgeModel;
using Newtonsoft.Json;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ShopBridgeEcomApi
{
    public class ApiControllerBase : ControllerBase
    {
        public String ConnectionString(ApiInputModel objm)
        {
            return ShopShared.MasterConnectionString;
        }
        public IActionResult ConvertResultToReturnObject(object obj, ReturnedObject.ReturnType type)
        {
            ReturnedObject data = new ReturnedObject();
            data.Data = obj;
            data.Type = type;   
            IActionResult response = Unauthorized();
            String Token = "";
            try
            {
                if (Token != null || Token != "")
                {
                    if (data.Type == ReturnedObject.ReturnType.Exception)
                        response =
                            Ok(new { Status = true, StatusCode = "Exception", message = "Success", result = data.Data });
                    if (data.Type == ReturnedObject.ReturnType.Failed)
                        response =
                            Ok(new { Status = true, StatusCode = "Failed", message = "Success", result = data.Data });
                    else
                        response = Ok(new { Status = true, StatusCode = "OK", message = "Success", result = data.Data });
                }
            }
            catch (Exception ex)
            {
                return response =
                            BadRequest(new { Status = true, StatusCode = "Exception", message = "Failed", result = ex });
            }
            return response;
        }
        public IActionResult ConvertResultToReturnObject(ReturnedObject data)
        {
            //ReturnedObject data = new ReturnedObject();
            //data.Data = obj;
            //data.Type = type;
            IActionResult response = Unauthorized();
            String Token = "";
            try
            {
                if (Token != null || Token != "")
                {
                    if (data.Type == ReturnedObject.ReturnType.Exception)
                        response =
                            Ok(new { Status = true, StatusCode = "Exception", message = "Success", result = data.Data });
                    else if (data.Type == ReturnedObject.ReturnType.Failed)
                        response =
                            Ok(new { Status = true, StatusCode = "Failed", message = "Success", result = data.Data });
                    else
                        response = Ok(new { Status = true, StatusCode = "OK", message = "Success", result = data.Data });
                }
            }
            catch (Exception ex)
            {
                return response =
                            BadRequest(new { Status = true, StatusCode = "Exception", message = "Failed", result = ex });
            }
            return response;
        }
        public T ConvertObjectToAnyModel<T>(string json)
        {
            return JsonConvert.DeserializeObject<T>(json);
        }
        public List<T> ConvertObjectToAnyModelList<T>(string json)
        {
            return JsonConvert.DeserializeObject<List<T>>(json);
        }
    }
}
