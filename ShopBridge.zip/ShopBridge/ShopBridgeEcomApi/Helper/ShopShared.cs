﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridgeEcomApi.Helper
{
    public class ShopShared
    {
        public static String ConnectionString
        {
            get
            {
                var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
                var Configuration = builder.Build();
                return Configuration.GetConnectionString("ConnectionString");
            }
        }
        public static String MasterConnectionString
        {
            get
            {
                var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
                var Configuration = builder.Build();
                StringBuilder sb = new StringBuilder();
                sb.Append("Data Source=");
                sb.Append(DataSource);
                sb.Append(";");
                sb.Append("Initial Catalog=");
                sb.Append(InitialCatalog);
                sb.Append(";");
                sb.Append("Integrated Security=SSPI;");
                //sb.Append("User ID=sa;Password=aniyan;");
                return sb.ToString();
            }
        }
        private static String DataSource
        {
            get
            {
                var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
                var Configuration = builder.Build();
                return Configuration.GetConnectionString("DataSource");
            }
        }
        // initial catelog
        private static String InitialCatalog
        {
            get
            {
                var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
                var Configuration = builder.Build();
                return Configuration.GetConnectionString("InitialCatalog");
            }
        }
    }
}
