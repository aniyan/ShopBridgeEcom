﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShopBridgeDAL;
using ShopBridgeModel;
using Microsoft.AspNetCore.Authorization;

namespace ShopBridgeEcomApi.Controllers
{
    [Produces("application/json")]
    [Route("api/")]
    public class ItemApiController : ApiControllerBase
    {
        #region Declaration
        ItemDAL objDAL;
        ApiInputModel inputModel = new ApiInputModel();
        ReturnedObject objConstructor = new ReturnedObject();
        #endregion
        #region Common Functions
        public void ObjDALinit()
        {
            if (objDAL == null) objDAL = new ItemDAL(ConnectionString(inputModel));
        }
        // GET: api/ItemApi
        #endregion
        [AllowAnonymous]
        [HttpPost]
        [Route("GetItemsList")]
        public async Task<IActionResult> GetItemsList([FromBody] ApiInputModel inputModel)
        {
            try
            {
                ObjDALinit();
                objConstructor = await objDAL.GetItemsList(inputModel.Username, inputModel.Language);
                return ConvertResultToReturnObject(objConstructor);
            }
            catch (Exception ex)
            {
                return ConvertResultToReturnObject(ex, ReturnedObject.ReturnType.Exception);
            }
        }
        [AllowAnonymous]
        [HttpPost]
        [Route("GetItem")]
        public async Task<IActionResult> GetItem([FromBody] ApiInputModel inputModel)
        {
            try
            {
                ObjDALinit();
                objConstructor = await objDAL.GetItem(inputModel.Username, inputModel.Language, inputModel.ID);
                return ConvertResultToReturnObject(objConstructor);
            }
            catch (Exception ex)
            {
                return ConvertResultToReturnObject(ex, ReturnedObject.ReturnType.Exception);
            }
        }
        [AllowAnonymous]
        [HttpPost]
        [Route("PutItems")]
        public async Task<IActionResult> PutItems([FromBody] ApiInputModel inputModel)
        {
            try
            {
                ObjDALinit();
                ItemModel objItem = new ItemModel();
                objItem = ConvertObjectToAnyModel<ItemModel>(inputModel.TypeObject.ToString());
                objConstructor = await objDAL.PutItems(inputModel.Username, inputModel.Language, objItem);
                return ConvertResultToReturnObject(objConstructor);
            }
            catch (Exception ex)
            {
                return ConvertResultToReturnObject(ex, ReturnedObject.ReturnType.Exception);
            }
        }
        [AllowAnonymous]
        [HttpPost]
        [Route("DeleteItem")]
        public async Task<IActionResult> DeleteItem([FromBody] ApiInputModel inputModel)
        {
            try
            {
                ObjDALinit();
                objConstructor = await objDAL.DeleteItem(inputModel.Username, inputModel.ID);
                return ConvertResultToReturnObject(objConstructor);
            }
            catch (Exception ex)
            {
                return ConvertResultToReturnObject(ex, ReturnedObject.ReturnType.Exception);
            }
        }
    }
}