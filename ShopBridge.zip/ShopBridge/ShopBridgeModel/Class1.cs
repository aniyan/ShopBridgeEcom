﻿using System;

namespace ShopBridgeModel
{
    public class Class1
    {
    }
}
