﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShopBridgeModel
{
    public class ItemModelList
    {
        public List<ItemModel> ItemsList { get; set; }
    }
    public class ItemModel : BaseModel
    {
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string ArabicItemName { get; set; }
        public string Description { get; set; }
        public string ArabicDescription { get; set; }
        public Boolean Active { get; set; }

    }
}
