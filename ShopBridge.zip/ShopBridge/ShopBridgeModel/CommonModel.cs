﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShopBridgeModel
{
    public class CommonModel
    {
    }

    public class ReturnedObject
    {
        public enum ReturnType { Ok, Exception, Failed, Saved, Deleted, Updated };
        public Object Data { get; set; }
        public ReturnType Type { get; set; }
    }

    public class ApiInputModel
    {
        public Int64 ID { get; set; }
        public Int32 MenuID { get; set; }
        public Int32 CompanyID { get; set; }
        public string Token { get; set; }
        public string Language { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string ApiMethod { get; set; }
        public string String1 { get; set; }
        public string String2 { get; set; }
        public string String3 { get; set; }
        public int PerPage { get; set; }
        public Int64 Int1 { get; set; }
        public Int64 Int2 { get; set; }
        public Int64 Int3 { get; set; }
        public Exception Exception { get; set; }
        public object TypeObject { get; set; }
        public object TypeObject1 { get; set; }
        public object TypeObject2 { get; set; }
        public object TypeObject3 { get; set; }
        public String ApiRootUrl { get; set; }
    }
    public class ApiOutputModel
    {
        public Int64? Int1 { get; set; }
        public Int64? Int2 { get; set; }
        public Int64? Int3 { get; set; }
        public String String1 { get; set; }
        public String String2 { get; set; }
        public String String3 { get; set; }
    }
}
