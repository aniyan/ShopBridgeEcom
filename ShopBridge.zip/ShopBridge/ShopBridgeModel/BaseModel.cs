﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShopBridgeModel
{
    public class BaseModel
    {
        public Int64 ID { get; set; }
        public DateTime Date { get; set; }
    }
}
