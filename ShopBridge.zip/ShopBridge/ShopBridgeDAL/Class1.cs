﻿
using System;

namespace ShopBridgeDAL
{
    public class Class1
    {
    }
}
