﻿using Newtonsoft.Json;
using ShopBridgeModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridgeDAL
{
    public class BaseDAL
    {
        public BaseDAL()
        { }
        public BaseDAL(String ConnectionString)
        {
            this.ConnectionString = ConnectionString;
        }
        public String ConnectionString { get; set; }
        public ReturnedObject ConvertResultToReturnObject(Object data, ReturnedObject.ReturnType type)
        {
            ReturnedObject obj = new ReturnedObject();
            obj.Data = data;
            obj.Type = type;
            return obj;
        }
        public DataTable ConvertObjectToDatatable(string json)
        {
            return JsonConvert.DeserializeObject<DataTable>(json);
        }
        public DataSet ConvertObjectToDataSet(string json)
        {
            return JsonConvert.DeserializeObject<DataSet>(json);
        }
        public T ConvertObjectToAnyModel<T>(string json)
        {
            return JsonConvert.DeserializeObject<T>(json);
        }
        public List<T> ConvertObjectToAnyModelList<T>(string json)
        {
            return JsonConvert.DeserializeObject<List<T>>(json);
        }
        public async Task<T> GetModelFromDataRow<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)
                    {
                        if (dr[column.ColumnName] != System.DBNull.Value)
                        {
                            pro.SetValue(obj, ChangeType(dr[column.ColumnName], pro.PropertyType), null);
                        }
                    }
                    else
                        continue;
                }
            }
            return obj;
        }
        public static object ChangeType(object value, Type conversion)
        {
            var t = conversion;

            if (t.IsGenericType && t.GetGenericTypeDefinition().Equals(typeof(Nullable<>)))
            {
                if (value == null)
                {
                    return null;
                }

                t = Nullable.GetUnderlyingType(t);
            }

            return Convert.ChangeType(value, t);
        }
    }
}
