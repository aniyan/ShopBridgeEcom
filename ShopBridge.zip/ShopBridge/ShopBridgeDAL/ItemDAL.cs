﻿using ShopBridgeModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridgeDAL
{
    public class ItemDAL : BaseDAL
    {
        public ItemDAL(String ConnectionString)
        {
            this.ConnectionString = ConnectionString;
        }
        public async Task<ReturnedObject> GetItemsList(String Username, String Language)
        {
            try
            {
                SqlConnection Con = new SqlConnection(ConnectionString);
                SqlCommand Cmd = new SqlCommand("InvItemMasterSP", Con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                Cmd.Parameters.AddWithValue("@Mode", 0);
                Cmd.Parameters.AddWithValue("@Username", Username);
                Cmd.Parameters.AddWithValue("@Language", Language);
                DataTable dt = new DataTable();
                await Task.Run(() => new SqlDataAdapter(Cmd).Fill(dt));
                return ConvertResultToReturnObject(dt, ReturnedObject.ReturnType.Ok);
            }
            catch (Exception ex)
            {
                return ConvertResultToReturnObject(ex, ReturnedObject.ReturnType.Exception);
            }
        }
        public async Task<ReturnedObject> GetItem(String Username, String Language, Int64 ID)
        {
            try
            {
                ItemModel OModel = new ItemModel();
                SqlConnection Con = new SqlConnection(ConnectionString);
                SqlCommand Cmd = new SqlCommand("InvItemMasterSP", Con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                Cmd.Parameters.AddWithValue("@Mode", 1);
                Cmd.Parameters.AddWithValue("@Username", Username);
                Cmd.Parameters.AddWithValue("@Language", Language);
                Cmd.Parameters.AddWithValue("@ID", ID);
                DataTable dt = new DataTable();
                await Task.Run(() => new SqlDataAdapter(Cmd).Fill(dt));
                if (dt.Rows.Count > 0)
                {
                    OModel = await GetModelFromDataRow<ItemModel>(dt.Rows[0]);
                }
                return ConvertResultToReturnObject(OModel, ReturnedObject.ReturnType.Ok);
            }
            catch (Exception ex)
            {
                return ConvertResultToReturnObject(ex, ReturnedObject.ReturnType.Exception);
            }
        }
        public async Task<ReturnedObject> PutItems(String Username, String Language, ItemModel ObjModel)
        {
            SqlConnection Con = null;
            SqlTransaction Tx = null;
            try
            {
                Con = new SqlConnection(ConnectionString);
                Con.Open();
                Tx = Con.BeginTransaction();
                SqlCommand Cmd = new SqlCommand("InvItemMasterSP", Con,Tx)
                {
                    CommandType = CommandType.StoredProcedure
                };
                Cmd.Parameters.AddWithValue("@Mode", 2);
                Cmd.Parameters.AddWithValue("@ID", ObjModel.ID);
                Cmd.Parameters.AddWithValue("@Username", Username);
                Cmd.Parameters.AddWithValue("@Language", Language);
                Cmd.Parameters.AddWithValue("@ItemCode", ObjModel.ItemCode);
                Cmd.Parameters.AddWithValue("@ItemName", ObjModel.ItemName);
                Cmd.Parameters.AddWithValue("@ArabicItemName", ObjModel.ArabicItemName);
                Cmd.Parameters.AddWithValue("@Description", ObjModel.Description);
                Cmd.Parameters.AddWithValue("@ArabicDescription", ObjModel.ArabicDescription);
                Cmd.Parameters.AddWithValue("@Active", ObjModel.Active);
                DataTable dt = new DataTable();
                await Task.Run(() => Cmd.ExecuteNonQuery());
                Tx.Commit();
                Con.Close();
                return ConvertResultToReturnObject(true, ReturnedObject.ReturnType.Ok);
            }
            catch (Exception ex)
            {
                if (Con != null && Con.State == ConnectionState.Open)
                {
                    Tx.Rollback();
                    Con.Close();
                }
                return ConvertResultToReturnObject(ex, ReturnedObject.ReturnType.Exception);
            }
        }
        public async Task<ReturnedObject> DeleteItem(String Username, Int64 ID)
        {
            SqlConnection Con = null;
            SqlTransaction Tx = null;
            try
            {
                Con = new SqlConnection(ConnectionString);
                Con.Open();
                Tx = Con.BeginTransaction();
                SqlCommand Cmd = new SqlCommand("InvItemMasterSP", Con,Tx)
                {
                    CommandType = CommandType.StoredProcedure
                };
                Cmd.Parameters.AddWithValue("@Mode", 3);
                Cmd.Parameters.AddWithValue("@Username", Username);
                Cmd.Parameters.AddWithValue("@ID", ID);
                DataTable dt = new DataTable();
                await Task.Run(() => Cmd.ExecuteNonQuery());
                Tx.Commit();
                Con.Close();
                return ConvertResultToReturnObject(true, ReturnedObject.ReturnType.Ok);
            }
            catch (Exception ex)
            {
                if (Con != null && Con.State == ConnectionState.Open)
                {
                    Tx.Rollback();
                    Con.Close();
                }
                return ConvertResultToReturnObject(ex, ReturnedObject.ReturnType.Exception);
            }
        }
    }
}
